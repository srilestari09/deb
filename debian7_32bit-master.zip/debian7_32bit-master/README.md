# debian7_32bit
Script Auto Install SSH dan OpenVPN untuk VPS Debian 7 32 bit dan 64 bit

http://www.masarif.tk/2017/06/script-auto-install-ssh-vpn-untuk-vps.html
