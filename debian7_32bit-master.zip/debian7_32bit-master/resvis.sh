#!/bin/bash
# Script restart service dropbear, webmin, squid3, openvpn, openssh
# Created by Bustami Arifin
service dropbear restart
service webmin restart
service squid3 restart
service openvpn restart
service ssh restart
