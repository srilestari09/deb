#!/bin/bash
#info

clear
neofetch